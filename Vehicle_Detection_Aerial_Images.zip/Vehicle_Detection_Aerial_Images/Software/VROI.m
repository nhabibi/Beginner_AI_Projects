figure(99);
imshow(VoriginalImage);
VROIImage = imcrop;
figure(98);
imshow(VROIImage);
